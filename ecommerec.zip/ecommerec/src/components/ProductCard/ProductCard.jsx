'use client'

import { StarIcon } from '@heroicons/react/20/solid'
import { Link } from 'react-router-dom'
import { useCart } from '../../context/CartContext'

export default function ProductCard({ product }) {
  const { addToCart } = useCart()

  const handleAddToCart = (e) => {
    e.preventDefault()
    e.stopPropagation()
    addToCart(product)
  }

  return (
    <Link to={`/product/${product.id}`} className="group">
      <div className="relative flex flex-col overflow-hidden rounded-lg bg-white shadow-md transition-all duration-300 hover:shadow-xl">
        {/* Product Image */}
        <div className="relative aspect-square w-full overflow-hidden bg-gray-100">
          <img
            src={product.image}
            alt={product.title}
            className="h-full w-full object-contain p-4 transition-transform duration-300 group-hover:scale-105"
          />
          {/* Category Badge */}
          <div className="absolute left-2 top-2 rounded-full bg-indigo-600 px-3 py-1 text-xs font-medium text-white">
            {product.category}
          </div>
        </div>

        {/* Product Info */}
        <div className="flex flex-1 flex-col p-4">
          {/* Title */}
          <h3 className="mb-2 line-clamp-2 text-sm font-medium text-gray-900">
            {product.title}
          </h3>

          {/* Rating */}
          <div className="mb-2 flex items-center">
            <div className="flex items-center">
              {[0, 1, 2, 3, 4].map((rating) => (
                <StarIcon
                  key={rating}
                  className={`h-4 w-4 flex-shrink-0 ${
                    product.rating.rate > rating ? 'text-yellow-400' : 'text-gray-200'
                  }`}
                  aria-hidden="true"
                />
              ))}
            </div>
            <span className="ml-1 text-xs text-gray-500">({product.rating.count})</span>
          </div>

          {/* Price */}
          <div className="mt-auto flex items-center justify-between">
            <p className="text-lg font-bold text-gray-900">${product.price.toFixed(2)}</p>
            <button
              onClick={handleAddToCart}
              className="rounded-full bg-indigo-600 p-2 text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-5 w-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </Link>
  )
} 